//
//  LoginModel.swift
//  KreamCloneCoding
//
//  Created by 김승원 on 9/25/24.
//

import Foundation

struct UserData {
    var id: String
    var password: String
}
