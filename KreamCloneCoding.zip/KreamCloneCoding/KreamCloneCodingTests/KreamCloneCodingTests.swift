//
//  KreamCloneCodingTests.swift
//  KreamCloneCodingTests
//
//  Created by 김승원 on 9/29/24.
//

import Testing
@testable import KreamCloneCoding

struct KreamCloneCodingTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
